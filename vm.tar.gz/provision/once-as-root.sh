#!/bin/bash

sudo yum update
sudo yum install -y nginx
sudo yum install -y epel-release yum-utils
sudo yum install -y http://rpms.remirepo.net/enterprise/remi-release-7.rpm
sudo yum-config-manager --enable remi-php71
sudo yum install -y php php-common php-opcache php-mcrypt php-cli php-gd php-curl php-mysqlsudo cp sync/project.local /etc/nginx/sites-available/project.local
cd /etc/nginx/conf.d
sudo ln -s /etc/nginx/conf.d/project.local
sudo cat /www/vhosts/sync/task2/config/project.local > /etc/hosts
sudo yum install -y php-fpm
cd /www/vhosts/sync/task2
sudo chmod -R 777 project.local